package com.company;

import com.company.controller.fileOperation;
import com.company.model.invoiceHeader;
import com.company.view.PrintSalesInvoice;
import com.opencsv.CSVReader;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class Main {
    private static final String invoiceLinePath= "src/com/company/resources/invoiceLine.csv";
    private static final String invoiceHeadersPath= "src/com/company/resources/invoiceHeader.csv";
    private static final String invoiceLinePath2= "src/com/company/resources/invoiceLine2.csv";
    private static final String invoiceHeadersPath2= "src/com/company/resources/invoiceHeader2.csv";

    public static void main(String[] args) throws FileNotFoundException {

        PrintSalesInvoice.PrintSalesInvoice(invoiceHeadersPath);
       // PrintSalesInvoice.PrintSalesInvoice(invoiceLinePath);

        System.out.println("Create invoiceLine.csv ");
        System.out.println("Headers of data(invoiceNum,itemName, itemPrice ,count) ");
      fileOperation.writeFile(invoiceLinePath2);
        System.out.println("Create invoiceHeaders.csv");
        System.out.println("Headers of data(invoiceNum,invoiceDate, customerName)");
        fileOperation.writeFile(invoiceHeadersPath2);



    }


}
